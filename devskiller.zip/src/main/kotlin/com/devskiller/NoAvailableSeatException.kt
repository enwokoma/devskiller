package com.devskiller

/**
 * Created by Emmanuel Nwokoma (Gigabyte) on 10/31/2022
 **/
class NoAvailableSeatException : Exception()